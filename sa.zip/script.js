function submitForm() {
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Validatsiya
    if (username && email && password) {
        // Barcha maydonlar to'g'ri kiritilgan
        alert("Barcha maydonlar to'g'ri kiritilgan.");
        // Yoki yana nima qilishni istasangiz, masalan, formani yuborish
    } else {
        // Maydonlardan biri yoki bir nechasi to'g'ri kiritilmagan
        alert("Iltimos, barcha maydonlarni to'g'ri to'ldiring!");
    }
}
